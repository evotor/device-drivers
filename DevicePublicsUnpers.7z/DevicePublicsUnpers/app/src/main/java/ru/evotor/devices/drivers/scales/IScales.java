package ru.evotor.devices.drivers.scales;

public interface IScales {

    Weight getWeight();

}
