package ru.evotor.devices.drivers.cashdrawer;

public interface ICashDrawer {

    void openCashDrawer();

}
